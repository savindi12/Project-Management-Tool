
const express=require("express"),mysql=require("mysql2/promise"),bcrypt=require("bcryptjs"),path=require("path");require("dotenv").config();
const app=express();app.use(express.json());app.use(express.static(path.join(__dirname,"public")));
const db=mysql.createPool({host:process.env.DB_HOST||"localhost",user:process.env.DB_USER||"root",password:process.env.DB_PASSWORD||"",database:process.env.DB_NAME||"codealpha_pm"});
app.post("/api/register",async(req,res)=>{try{let h=await bcrypt.hash(req.body.password,10),[r]=await db.query("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)",[req.body.name,req.body.email,h]);res.json({id:r.insertId,name:req.body.name})}catch(e){res.status(400).json({error:e.message})}});
app.post("/api/login",async(req,res)=>{let [u]=await db.query("SELECT * FROM users WHERE email=?",[req.body.email]);if(!u.length||!(await bcrypt.compare(req.body.password,u[0].password_hash)))return res.status(401).json({error:"Invalid login"});res.json({id:u[0].id,name:u[0].name})});
app.get("/api/projects",async(req,res)=>{let [r]=await db.query("SELECT * FROM projects WHERE owner_id=? OR id IN(SELECT project_id FROM project_members WHERE user_id=?) ORDER BY created_at DESC",[req.query.userId,req.query.userId]);res.json(r)});
app.post("/api/projects",async(req,res)=>{let [r]=await db.query("INSERT INTO projects(owner_id,name,description) VALUES(?,?,?)",[req.body.userId,req.body.name,req.body.description||""]);res.json({id:r.insertId})});
app.get("/api/projects/:id/tasks",async(req,res)=>{let [r]=await db.query(`SELECT t.*,u.name assignee_name FROM tasks t LEFT JOIN users u ON u.id=t.assigned_to WHERE project_id=? ORDER BY FIELD(status,'Todo','Doing','Done'),id DESC`,[req.params.id]);res.json(r)});
app.post("/api/projects/:id/tasks",async(req,res)=>{let [r]=await db.query("INSERT INTO tasks(project_id,title,description,assigned_to) VALUES(?,?,?,?)",[req.params.id,req.body.title,req.body.description||"",req.body.assignedTo||null]);res.json({id:r.insertId})});
app.patch("/api/tasks/:id",async(req,res)=>{await db.query("UPDATE tasks SET status=COALESCE(?,status),assigned_to=COALESCE(?,assigned_to) WHERE id=?",[req.body.status,req.body.assignedTo,req.params.id]);res.json({ok:true})});
app.get("/api/tasks/:id/comments",async(req,res)=>{let [r]=await db.query("SELECT c.*,u.name FROM task_comments c JOIN users u ON u.id=c.user_id WHERE task_id=? ORDER BY c.created_at",[req.params.id]);res.json(r)});
app.post("/api/tasks/:id/comments",async(req,res)=>{await db.query("INSERT INTO task_comments(task_id,user_id,content) VALUES(?,?,?)",[req.params.id,req.body.userId,req.body.content]);res.json({ok:true})});
app.listen(process.env.PORT||3003,()=>console.log("Project Manager: http://localhost:"+(process.env.PORT||3003)));
